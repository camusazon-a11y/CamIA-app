# 🚀 CAMIA — GUIDE DE DÉPLOIEMENT
## Par Camus Azon · Bénin 🇧🇯

---

## 📁 FICHIERS INCLUS
- index.html  → L'application complète
- manifest.json → Configuration PWA (installable)
- sw.js → Service Worker (notifications)
- GUIDE.md → Ce guide

---

## 🌐 MISE EN LIGNE EN 5 MINUTES (Netlify)

### Étape 1 — Créer un compte Netlify
1. Va sur → https://netlify.com
2. Clique "Sign up" → Inscription gratuite

### Étape 2 — Déployer
1. Dans Netlify, clique "Add new site"
2. Choisis "Deploy manually"
3. GLISSE-DÉPOSE le dossier entier (les 4 fichiers)
4. ✅ Ton app est en ligne en 30 secondes !

### Étape 3 — Ton lien
Tu obtiens un lien comme : https://camia-xxxx.netlify.app
Tu peux le personnaliser → Settings → Domain → camia.netlify.app

---

## 📱 INSTALLATION SUR ANDROID

1. Ouvre le lien dans Chrome Android
2. Chrome affiche automatiquement "Ajouter à l'écran d'accueil"
3. L'app s'installe comme une vraie appli ✅
4. Icône CamIA apparaît sur le bureau du téléphone

---

## 🏪 GOOGLE PLAY STORE

1. Va sur → https://pwabuilder.com
2. Entre ton lien Netlify
3. Clique "Build" → Télécharge le package Android
4. Va sur → https://play.google.com/console
5. Crée un compte développeur (25$ une seule fois)
6. Soumets l'app → Validation en 3-7 jours

---

## 👑 TES IDENTIFIANTS ADMIN

Email    : admin@camia.bj
Password : CamIA2026!

⚠️ GARDE CES INFORMATIONS SECRÈTES

---

## 💰 TARIFS INTÉGRÉS

- Musique : 500 FCFA (1 gratuit par compte)
- Vidéo 10s : 1 000 FCFA (avec watermark CamIA)
- Vidéo 20s : 5 000 FCFA
- Vidéo 30s : 10 000 FCFA

Paiement : MTN 0162455873 · Moov 0165383169

---

## 🛡️ SÉCURITÉ

✅ Connexion Google obligatoire
✅ Contenu adulte/inapproprié bloqué automatiquement
✅ Système d'avertissements (3 max → suspension)
✅ Admin séparé avec mot de passe fort
✅ Notifications push activables

---

CamIA · Par Camus Azon · Bénin 🇧🇯 · 2026
