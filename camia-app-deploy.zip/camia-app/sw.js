// CamIA Service Worker — Notifications + Mode hors ligne
const CACHE_NAME = 'camia-v1';
const urlsToCache = ['/'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(urlsToCache)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(clients.claim());
});

self.addEventListener('fetch', e => {
  e.respondWith(
    fetch(e.request).catch(() => caches.match(e.request))
  );
});

// Push notifications
self.addEventListener('push', e => {
  const data = e.data ? e.data.json() : {};
  e.waitUntil(
    self.registration.showNotification(data.title || 'CamIA', {
      body: data.body || 'Ta génération est prête !',
      icon: 'https://via.placeholder.com/192/e94560/ffffff?text=CIA',
      badge: 'https://via.placeholder.com/72/e94560/ffffff?text=C',
      tag: 'camia-push',
      data: { url: data.url || '/' }
    })
  );
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.openWindow(e.notification.data?.url || '/'));
});
